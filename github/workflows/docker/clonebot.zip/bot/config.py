import os
import json
from distutils.util import strtobool as stb

# --------------------------------------
BOT_TOKEN = os.environ.get('BOT_TOKEN')
GDRIVE_FOLDER_ID = "0ADWS1XPq6WKnUk9PVA"
# Default folder id.
OWNER_ID = 123456789
AUTHORISED_USERS = [123,456,789]
# Example: AUTHORISED_USERS = [63055333, 100483029, -1003943959]
INDEX_URL = ""
IS_TEAM_DRIVE = True
USE_SERVICE_ACCOUNTS = False
# --------------------------------------
